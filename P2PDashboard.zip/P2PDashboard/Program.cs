// Create the web application builder
var builder = WebApplication.CreateBuilder(args);

// Add MVC Controllers and Views so dashboard pages can load
builder.Services.AddControllersWithViews();

// Build the actual web application from builder
var app = builder.Build();

// If NOT in Development mode (example: in Production), use the error page
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error"); // Show custom error page
    app.UseHsts(); // Force browser to use secure HTTPS only
}

// Force HTTPS (redirect HTTP to HTTPS)
app.UseHttpsRedirection();

// Allow loading CSS, JS, images from wwwroot folder
app.UseStaticFiles();

// Enable routing (MVC can find controllers and actions)
app.UseRouting();

// Set default route: HomeController -> Index()
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Run the web app (start listening for requests)
app.Run();
