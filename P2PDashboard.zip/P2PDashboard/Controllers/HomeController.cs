using Microsoft.AspNetCore.Mvc;

namespace P2PDashboardSite.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
    }
}
