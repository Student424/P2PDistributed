﻿namespace P2PDashboard.Models
{
    // This class represents 1 client (one P2P node) in our swarm network
    public class ClientInfo
    {
        // Unique ID in the database
        public int Id { get; set; }

        // The client's IP address
        public string IpAddress { get; set; }

        // The port number used by the client's Remoting server
        public int Port { get; set; }

        // How many jobs this client has finished
        public int JobsCompleted { get; set; }

        // Last time (in UTC) that the client contacted the Web Service
        // Used to check if the client is dead or offline
        public System.DateTime LastSeenUtc { get; set; }
    }
}
