﻿using System.ComponentModel.DataAnnotations;

namespace ClientRegistryWebService.Models
{
    // Represents one client in the database
    // The Web Service will save one record for each connected client
    public class ClientInfo
    {
        // Primary key in the database (auto-generated ID)
        [Key]
        public int Id { get; set; }

        // The client's IP address
        // Required = cannot be empty
        [Required]
        public string IpAddress { get; set; } = string.Empty;

        // The port number the client uses for .NET Remoting (example: 9000).
        // Required = must have a value.
        [Required]
        public int Port { get; set; }

        // How many jobs this client has finished.
        // Default value is 0.
        public int JobsCompleted { get; set; } = 0;
    }
}
