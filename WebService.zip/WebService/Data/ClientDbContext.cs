﻿using ClientRegistryWebService.Models;
using Microsoft.EntityFrameworkCore;

namespace ClientRegistryWebService.Data
{
    // Database connection for our Web Service
    // It uses Entity Framework Core to talk to local SQL database.
    public class ClientDbContext : DbContext
    {
        // The constructor receives database options (like connection string)
        // and passes them to the base DbContext class
        public ClientDbContext(DbContextOptions<ClientDbContext> options) : base(options) { }

        // Creates a table named "Clients" in the database.
        // It will store a list of ClientInfo objects (IP, Port, JobsCompleted).
        public DbSet<ClientInfo> Clients { get; set; }
    }
}
