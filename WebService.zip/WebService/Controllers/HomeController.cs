using Microsoft.AspNetCore.Mvc;

namespace ClientRegistryWebService.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
    }
}
