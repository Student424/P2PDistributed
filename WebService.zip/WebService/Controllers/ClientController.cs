﻿using Microsoft.AspNetCore.Mvc;
using ClientRegistryWebService.Data;
using ClientRegistryWebService.Models;

namespace ClientRegistryWebService.Controllers
{
    // This makes the URL look like:  /api/client/...
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        // Database connection (Entity Framework)
        private readonly ClientDbContext _db;

        // Used to prevent 2 threads from editing the DB at the same time
        private static readonly object _lock = new();

        // Constructor - gets the database from dependency injection
        public ClientController(ClientDbContext db) => _db = db;

        // REGISTER CLIENT
        // POST: /api/client/register
        // Client sends IP + Port to server
        [HttpPost("register")]
        public IActionResult Register([FromBody] ClientInfo dto)
        {
            // Basic validation
            if (dto == null || string.IsNullOrWhiteSpace(dto.IpAddress) || dto.Port < 1024 || dto.Port > 65535)
                return BadRequest("Invalid client.");

            lock (_lock) // Make database changes thread-safe
            {
                // Check if client exists (same IP + Port)
                var existing = _db.Clients.FirstOrDefault(c => c.IpAddress == dto.IpAddress && c.Port == dto.Port);

                // If new, add to database. If exists, update JobsCompleted
                if (existing == null) _db.Clients.Add(dto);
                else existing.JobsCompleted = dto.JobsCompleted;

                _db.SaveChanges();
            }
            return Ok();
        }

        // GET CLIENT LIST
        // GET: /api/client/list
        // Used by dashboard and clients to get all connected peers
        [HttpGet("list")]
        public IActionResult List() => Ok(_db.Clients.ToList());

        // UPDATE JOB COUNT
        // POST: /api/client/updatejobs
        // Client sends updated "JobsCompleted" number
        [HttpPost("updatejobs")]
        public IActionResult UpdateJobs([FromBody] ClientInfo dto)
        {
            if (dto == null) return BadRequest();

            lock (_lock)
            {
                var existing = _db.Clients.FirstOrDefault(c => c.IpAddress == dto.IpAddress && c.Port == dto.Port);
                if (existing == null) return NotFound();

                existing.JobsCompleted = dto.JobsCompleted;
                _db.SaveChanges();
            }
            return Ok();
        }

        // REMOVE DEAD CLIENT
        // POST: /api/client/remove
        // Called when a peer cannot be reached anymore
        [HttpPost("remove")]
        public IActionResult RemoveClient([FromBody] ClientInfo dto)
        {
            if (dto == null) return BadRequest();

            lock (_lock)
            {
                var existing = _db.Clients
                    .FirstOrDefault(c => c.IpAddress == dto.IpAddress && c.Port == dto.Port);

                if (existing != null)
                {
                    _db.Clients.Remove(existing);
                    _db.SaveChanges();
                    Console.WriteLine($"[Cleanup] Removed dead client {dto.IpAddress}:{dto.Port}");
                }
            }

            return Ok();
        }
    }
}
