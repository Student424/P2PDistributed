using ClientRegistryWebService.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 1. Connect to Database (Local DB)
// Tells the app to use SQL Server and our ClientDbContext
// Loads the connection string from appsettings.json
builder.Services.AddDbContext<ClientDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("ClientDbConnection")));

// 2. Add API Controllers
// Allows the project to use Web API endpoints (like /api/client/list)
builder.Services.AddControllers();

// 3. Enable CORS (Cross-Origin Resource Sharing)
// Allows other apps (Dashboard website + Clients) to call our Web API
// Allow: any IP, any HTTP method (GET/POST), any header
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
        policy.AllowAnyOrigin()   // Allow any IP/website to call API
              .AllowAnyHeader()
              .AllowAnyMethod());
});

var app = builder.Build();

// 4. Apply CORS here (must be before controllers)
app.UseCors("AllowAll");

// 5. Force HTTPS redirection
// Makes web calls more secure
app.UseHttpsRedirection();

// 6. Map Controller Routes
// Activates your Web API endpoints
// Example: GET http://localhost:5274/api/client/list
app.MapControllers();

// Run the Web Service
app.Run();
