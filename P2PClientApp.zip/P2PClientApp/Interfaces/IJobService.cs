﻿// Target framework: .NET Framework 4.8
// IJobService ensures every client has the same job-related functionality

using System.Collections.Generic;
using P2PClientApp.Models;

namespace P2PClientApp.Interfaces
{
    // This tells what functions every Job Service must have
    // Every client must follow to communicate using .NET Remoting
    public interface IJobService
    {
        // Get a list of all jobs that are waiting to be solved
        List<Job> ListJobs();

        // Download one job by using its Job ID
        // Another client will run this job
        Job DownloadJob(string jobId);

        // After finishing the job, send back the answer/result
        // Returns true if the answer was received
        bool SubmitSolution(string jobId, string resultBase64);

        // Adds a new job to the local job list
        // Returns true if the job is successfully posted
        bool PostJob(Job j);
    }
}
