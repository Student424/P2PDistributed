﻿// WinForms main form — this controls the GUI, networking thread, and server logic
using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using RestSharp;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;
using P2PClientApp.Interfaces;
using P2PClientApp.Models;
using P2PClientApp.Services;
using P2PClientApp.Utilities;

namespace P2PClientApp
{
    public partial class Form1 : Form
    {
        // Remoting channel for communication
        private TcpChannel _channel;

        // Selected port for this client
        private int _port = 9000;

        // Flag to control networking loop (true = running, false = stop)
        private volatile bool _running = false;

        // Task that runs networking work in the background
        private Task _networkTask;

        // Local job service (stores and shares jobs)
        private JobService _jobServiceInstance;

        // Count of jobs this client has completed
        private int _jobsCompleted = 0;

        // Base URL of the Web Service (registry server)
        private string _webServiceBase = "http://localhost:5274";

        // Local IP address used by this client
        private string _localIp = "127.0.0.1";


        public Form1()
        {
            InitializeComponent();
            numPort.Value = 9000;
            lblStatus.Text = "Stopped";
            lblJobsDone.Text = "0";
        }

        // =============== SERVER CONTROL (Remoting server for other peers) ===============
        private void StartServer(int port)
        {
            try
            {
                _port = port;
                _jobServiceInstance = new JobService(); // job storage
                _channel = new TcpChannel(port);
                ChannelServices.RegisterChannel(_channel, false);

                // Register .NET Remoting service so other peers can call this client
                System.Runtime.Remoting.RemotingConfiguration.RegisterWellKnownServiceType(
                    typeof(JobService),
                    "JobService",
                    System.Runtime.Remoting.WellKnownObjectMode.Singleton);

                Log($"Server started on tcp://{_localIp}:{_port}/JobService");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to start remoting server: " + ex.Message);
                Log("ERROR starting server: " + ex.Message);
            }
        }

        private void StopServer()
        {
            try
            {
                if (_channel != null)
                {
                    ChannelServices.UnregisterChannel(_channel); // close channel
                    _channel = null;
                }
                Log("Server stopped.");
            }
            catch (Exception ex)
            {
                Log("ERROR stopping server: " + ex.Message);
            }
        }

        // =============== BUTTON EVENTS ===============
        private void btnStart_Click(object sender, EventArgs e)
        {
            if (_running) return;
            _running = true;

            // Get chosen port and local IP
            _port = (int)numPort.Value;
            _localIp = GetLocalIPAddress() ?? "127.0.0.1";

            // Start server + networking
            StartServer(_port);
            StartNetworkingThread();

            lblStatus.Text = $"Running on {_localIp}:{_port}";
            Log($"Client started. Local IP: {_localIp}, Port: {_port}");
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _running = false;
            StopServer();
            lblStatus.Text = "Stopped";
            Log("Client stopped.");
        }

        private void btnPostJob_Click(object sender, EventArgs e)
        {
            // Prevent posting when server is not running
            if (!_running || _jobServiceInstance == null)
            {
                MessageBox.Show("Please start the server before posting a job.");
                return;
            }

            // Read Python text from textbox
            var python = txtPython.Text;
            if (string.IsNullOrWhiteSpace(python))
            {
                MessageBox.Show("Enter Python code first.");
                return;
            }

            // Create job and encode as Base64
            var job = new Job
            {
                JobId = Guid.NewGuid().ToString("N"),
                EncodedPythonBase64 = NetworkUtils.ToBase64(python)
            };
            job.Sha256Hex = NetworkUtils.ComputeSha256Hex(job.EncodedPythonBase64);

            // Add job to local job board
            var posted = _jobServiceInstance.PostJob(job);
            if (posted)
            {
                var output = RunPythonWithIronPython(python);
                MessageBox.Show("Job posted to local board.\n\nPython output:\n" + output);
            }
            else
            {
                MessageBox.Show("Failed to post job (duplicate?).");
            }
        }

        private void btnLoadFile_Click(object sender, EventArgs e)
        {
            // Load Python file into textbox
            using (var dlg = new OpenFileDialog())
            {
                dlg.Filter = "Python files|*.py|Text files|*.txt|All files|*.*";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    txtPython.Text = System.IO.File.ReadAllText(dlg.FileName);
                    Log($"Loaded script from file: {dlg.FileName}");
                }
            }
        }

        // =============== NETWORK THREAD (loop that fetches peers + jobs) ===============
        private void StartNetworkingThread()
        {
            // Run in background thread so UI does not freeze
            _networkTask = Task.Run(() =>
            {
                try
                {
                    while (_running)
                    {
                        try
                        {
                            // 1) Register self to WebService
                            RegisterWithWebService();

                            // 2) Get peer list from WebService
                            var clients = GetClientsFromWebService();
                            Log($"Fetched {clients.Count} clients from registry.");

                            // 3) Loop through peers and try to fetch jobs
                            foreach (var client in clients)
                            {
                                try
                                {
                                    // Skip myself
                                    if (client.IpAddress == _localIp && client.Port == _port)
                                        continue;

                                    // Validate peer IP and Port
                                    if (!IPAddress.TryParse(client.IpAddress, out IPAddress _))
                                    {
                                        Log($"Skip invalid IP: {client.IpAddress}");
                                        continue;
                                    }
                                    if (client.Port < 1024 || client.Port > 65535)
                                    {
                                        Log($"Skip invalid port: {client.Port}");
                                        continue;
                                    }

                                    // Create connection URL to peer
                                    var url = $"tcp://{client.IpAddress}:{client.Port}/JobService";
                                    IJobService remote = null;

                                    // Try connect to peer
                                    try
                                    {
                                        remote = (IJobService)Activator.GetObject(typeof(IJobService), url);
                                    }
                                    catch (Exception ex)
                                    {
                                        Log($"Peer connect error ({url}): {ex.Message}.");
                                        continue;
                                    }

                                    if (remote == null)
                                    {
                                        Log($"Peer unreachable (null proxy) {client.IpAddress}:{client.Port}");
                                        continue;
                                    }

                                    // Ask peer for available jobs
                                    List<Job> jobs;
                                    try
                                    {
                                        jobs = remote.ListJobs();
                                    }
                                    catch (Exception ex)
                                    {
                                        Log($"Peer call failed: ListJobs {ex.Message}");
                                        continue;
                                    }

                                    // No jobs at this peer
                                    if (jobs == null || jobs.Count == 0)
                                    {
                                        Log($"No jobs at {client.IpAddress}:{client.Port}");
                                        continue;
                                    }

                                    Log($"Found {jobs.Count} job(s) at {client.IpAddress}:{client.Port}");

                                    // Download + Execute each job
                                    foreach (var job in jobs)
                                    {
                                        if (job == null) continue;

                                        // Check SHA256 hash
                                        if (!NetworkUtils.VerifySha256Hex(job.EncodedPythonBase64, job.Sha256Hex))
                                        {
                                            Log($"Job {job.JobId} failed hash verification. Skipping.");
                                            continue;
                                        }

                                        // Download job
                                        Job downloaded = null;
                                        try
                                        {
                                            downloaded = remote.DownloadJob(job.JobId);
                                        }
                                        catch (Exception ex)
                                        {
                                            Log($"DownloadJob failed: {ex.Message}");
                                            continue;
                                        }
                                        if (downloaded == null) continue;

                                        // Decode + run Python
                                        var py = NetworkUtils.FromBase64(downloaded.EncodedPythonBase64);
                                        var result = RunPythonWithIronPython(py);
                                        var resultBase64 = NetworkUtils.ToBase64(result ?? "");

                                        // Submit result back to peer
                                        bool ok = false;
                                        try
                                        {
                                            ok = remote.SubmitSolution(downloaded.JobId, resultBase64);
                                        }
                                        catch (Exception ex)
                                        {
                                            Log($"SubmitSolution failed: {ex.Message}");
                                            continue;
                                        }

                                        // If success -> update counters
                                        if (ok)
                                        {
                                            _jobsCompleted++;
                                            this.Invoke((Action)(() => lblJobsDone.Text = _jobsCompleted.ToString()));
                                            UpdateJobsToWebService();
                                            Log($"Job {downloaded.JobId} completed.");
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log($"Peer loop error: {ex.Message}");
                                }

                                if (!_running) break;
                            }
                        }
                        catch (Exception ex)
                        {
                            Log($"Networking iteration error: {ex.Message}");
                        }

                        // Wait before next peer scan
                        for (int i = 0; i < 10 && _running; i++)
                            Thread.Sleep(500);
                    }
                }
                catch (Exception ex)
                {
                    this.Invoke((Action)(() => MessageBox.Show("Network thread error: " + ex.Message)));
                    Log("FATAL network thread error: " + ex.Message);
                }
            });
        }

        // Send registration to WebService
        private void RegisterWithWebService()
        {
            try
            {
                if (!IPAddress.TryParse(_localIp, out _)) { Log("Invalid local IP, skip registration."); return; }
                if (_port < 1024 || _port > 65535) { Log("Invalid local port, skip registration."); return; }

                var dto = new ClientInfoDto { IpAddress = _localIp, Port = _port, JobsCompleted = _jobsCompleted };
                var client = new RestClient(_webServiceBase);
                var request = new RestRequest("/api/client/register", Method.Post);
                request.AddJsonBody(dto);
                var resp = client.Execute(request);

                if (!resp.IsSuccessful)
                    Log("Register failed: " + (resp.Content ?? "(no content)"));
                else
                    Log("Registered with registry.");
            }
            catch (Exception ex)
            {
                Log("Register exception: " + ex.Message);
            }
        }

        // Get list of peers from WebService
        private List<ClientInfoDto> GetClientsFromWebService()
        {
            var result = new List<ClientInfoDto>();
            try
            {
                var client = new RestClient(_webServiceBase);
                var request = new RestRequest("/api/client/list", Method.Get);
                var resp = client.Execute(request);

                if (!resp.IsSuccessful || string.IsNullOrWhiteSpace(resp.Content))
                {
                    Log("Fetch clients failed.");
                    return result;
                }

                result = JsonConvert.DeserializeObject<List<ClientInfoDto>>(resp.Content) ?? new List<ClientInfoDto>();
            }
            catch (Exception ex)
            {
                Log("Fetch clients exception: " + ex.Message);
            }
            return result;
        }

        // Update own job count in WebService
        private void UpdateJobsToWebService()
        {
            try
            {
                var dto = new ClientInfoDto { IpAddress = _localIp, Port = _port, JobsCompleted = _jobsCompleted };
                var client = new RestClient(_webServiceBase);
                var request = new RestRequest("/api/client/updatejobs", Method.Post);
                request.AddJsonBody(dto);
                client.Execute(request);
                Log("Updated job count to registry.");
            }
            catch (Exception ex)
            {
                Log("UpdateJobs exception: " + ex.Message);
            }
        }

        // =============== HELPER FUNCTIONS ===============
        private string RunPythonWithIronPython(string pythonCode)
        {
            try
            {
                // Create Python engine
                ScriptEngine engine = Python.CreateEngine();
                ScriptScope scope = engine.CreateScope();

                // Capture print output
                var ms = new System.IO.MemoryStream();
                var writer = new System.IO.StreamWriter(ms, Encoding.UTF8) { AutoFlush = true };
                engine.Runtime.IO.SetOutput(ms, writer);

                // Run script
                var source = engine.CreateScriptSourceFromString(pythonCode);
                var resultObj = source.Execute(scope);

                // Read captured output
                ms.Position = 0;
                var sr = new System.IO.StreamReader(ms, Encoding.UTF8);
                string output = sr.ReadToEnd();

                // If script returned a value, append it to output
                if (resultObj != null)
                {
                    var resStr = resultObj.ToString();
                    if (!string.IsNullOrWhiteSpace(resStr))
                        output = string.IsNullOrWhiteSpace(output) ? resStr : (output + "\n" + resStr);
                }

                return string.IsNullOrWhiteSpace(output) ? "" : output.Trim();
            }
            catch (Exception ex)
            {
                return "PY_ERR: " + ex.Message;
            }
        }

        // Get LAN IP (not localhost) if possible
        private string GetLocalIPAddress()
        {
            try
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());
                foreach (var ip in host.AddressList)
                {
                    if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        return ip.ToString();
                }
            }
            catch { }
            return "127.0.0.1";
        }

        // Write log into bottom textbox
        private void Log(string msg)
        {
            try
            {
                // If coming from background thread, switch to UI thread
                if (this.InvokeRequired)
                {
                    this.Invoke((Action)(() => Log(msg)));
                    return;
                }

                var line = $"[{DateTime.Now:HH:mm:ss}] {msg}";
                txtLog.AppendText(line + Environment.NewLine);
            }
            catch { }
        }

        // Shortens long Python output for log display
        private static string TrimForLog(string text, int max = 120)
        {
            if (string.IsNullOrEmpty(text)) return "(empty)";
            var oneLine = text.Replace("\r", " ").Replace("\n", " ").Trim();
            return oneLine.Length <= max ? oneLine : oneLine.Substring(0, max) + "...";
        }

        // =============== UI LAYOUT (auto-generated style, we do not touch logic here) ===============
        private TextBox txtPython;
        private Button btnPostJob;
        private Button btnStart;
        private Button btnStop;
        private Button btnLoadFile;
        private Label lblStatus;
        private Label lblJobsDone;
        private NumericUpDown numPort;
        private TextBox txtLog;

        private void InitializeComponent()
        {
            this.txtPython = new TextBox();
            this.btnPostJob = new Button();
            this.btnStart = new Button();
            this.btnStop = new Button();
            this.btnLoadFile = new Button();
            this.lblStatus = new Label();
            this.lblJobsDone = new Label();
            this.numPort = new NumericUpDown();
            this.txtLog = new TextBox();

            ((System.ComponentModel.ISupportInitialize)(this.numPort)).BeginInit();
            this.SuspendLayout();

            // txtPython
            this.txtPython.Location = new System.Drawing.Point(12, 12);
            this.txtPython.Multiline = true;
            this.txtPython.ScrollBars = ScrollBars.Vertical;
            this.txtPython.Size = new System.Drawing.Size(560, 300);

            // btnPostJob
            this.btnPostJob.Location = new System.Drawing.Point(12, 320);
            this.btnPostJob.Size = new System.Drawing.Size(100, 30);
            this.btnPostJob.Text = "Post Job";
            this.btnPostJob.Click += new EventHandler(this.btnPostJob_Click);

            // btnLoadFile
            this.btnLoadFile.Location = new System.Drawing.Point(118, 320);
            this.btnLoadFile.Size = new System.Drawing.Size(100, 30);
            this.btnLoadFile.Text = "Load File";
            this.btnLoadFile.Click += new EventHandler(this.btnLoadFile_Click);

            // numPort
            this.numPort.Location = new System.Drawing.Point(400, 320);
            this.numPort.Maximum = 65000;
            this.numPort.Minimum = 1024;
            this.numPort.Value = 9000;
            this.numPort.Size = new System.Drawing.Size(80, 22);

            // btnStart
            this.btnStart.Location = new System.Drawing.Point(490, 320);
            this.btnStart.Size = new System.Drawing.Size(80, 30);
            this.btnStart.Text = "Start";
            this.btnStart.Click += new EventHandler(this.btnStart_Click);

            // btnStop
            this.btnStop.Location = new System.Drawing.Point(490, 356);
            this.btnStop.Size = new System.Drawing.Size(80, 30);
            this.btnStop.Text = "Stop";
            this.btnStop.Click += new EventHandler(this.btnStop_Click);

            // lblStatus
            this.lblStatus.Location = new System.Drawing.Point(12, 360);
            this.lblStatus.Size = new System.Drawing.Size(300, 23);
            this.lblStatus.Text = "Status: Stopped";

            // lblJobsDone
            this.lblJobsDone.Location = new System.Drawing.Point(318, 360);
            this.lblJobsDone.Size = new System.Drawing.Size(120, 23);
            this.lblJobsDone.Text = "0";

            // txtLog
            this.txtLog.Location = new System.Drawing.Point(12, 390);
            this.txtLog.Multiline = true;
            this.txtLog.ScrollBars = ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(560, 160);
            this.txtLog.ReadOnly = true;

            // Form window
            this.ClientSize = new System.Drawing.Size(584, 562);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.numPort);
            this.Controls.Add(this.lblJobsDone);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnPostJob);
            this.Controls.Add(this.txtPython);
            this.Controls.Add(this.btnLoadFile);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Text = "P2P Client";

            ((System.ComponentModel.ISupportInitialize)(this.numPort)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
